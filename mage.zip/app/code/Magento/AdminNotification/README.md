# Admin Notification

**Admin Notification** provides the ability to alert administrators via
system messages and provides a message inbox for surveys and notifications.
