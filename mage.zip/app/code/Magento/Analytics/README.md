## Overview

The Magento_Analytics module provides integration with 
[Magento Business Intelligence](https://magento.com/products/business-intelligence). Admin user can subscribe to
Advanced Analytics, navigate to Advanced Analytics reports and Magento Business Intelligence subscription page.

The Magento_Analytics module adds:

- Advanced Analytics subscription pop-up
- backend menu link to Magento  Business Intelligence subscription page under Reports menu
- Magento Analytics configuration page in Stores-Configuration->General menu
- configuration to build a data collection for BI system