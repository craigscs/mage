<?php

namespace Gradus\Accessories\Controller\Adminhtml\Product;

class AccessoriesGrid extends Accessories
{
    
}